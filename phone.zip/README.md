PhoneGap-Start
---

A starting point for PhoneGap apps.

To get started: fork this repo, modify the config.xml to match your details, and get building!
